import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class StudentDetails extends BaseSchema {
  protected tableName = 'student_details'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.string('first_name', 50).notNullable()
      table.string('last_name', 50).notNullable()
      table.string('full_name', 100).notNullable()
      table.string('register_number', 20).primary()
      table.string('phone_number', 20).notNullable()
      table.string('mail_id', 100).notNullable()
      table.integer('maths').notNullable()
      table.integer('science').notNullable()
      table.integer('english').notNullable()
      table.integer('total').notNullable()

      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
