import BaseSeeder from '@ioc:Adonis/Lucid/Seeder'

import StudentDetail from 'App/Models/StudentDetail'

export default class StudentDetailsSeeder extends BaseSeeder {
  public async run() {
    await StudentDetail.create({
      firstName: 'Abi',
      lastName: 'A',
      fullName: 'Abi A',
      registerNumber: '12',
      phoneNumber: '99948845581',
      mailID: 'abi@gmail.com',
      maths: 99,
      science: 55,
      english: 88,
      total: 160,
    })
  }
}
