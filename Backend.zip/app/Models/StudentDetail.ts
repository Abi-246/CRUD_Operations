import { DateTime } from 'luxon'
import { BaseModel, column } from '@ioc:Adonis/Lucid/Orm'

export default class StudentDetail extends BaseModel {
  @column({ isPrimary: true })
  public registerNumber: string

  @column()
  public firstName: string

  @column()
  public lastName: string

  @column()
  public fullName: string

  @column()
  public phoneNumber: string

  @column()
  public mailID: string

  @column()
  public maths: number

  @column()
  public science: number

  @column()
  public english: number

  @column()
  public total: number

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
