import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import StudentDetail from 'App/Models/StudentDetail'

export default class StudentsController {
  public async getStudent({ response }: HttpContextContract) {
    try {
      const students = await StudentDetail.all()
      return response.send(students)
    } catch (error) {
      return response.status(500).json({ error: "Failed to fetch student details" })
    }
  }
}
